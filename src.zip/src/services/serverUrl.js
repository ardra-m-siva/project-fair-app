const serverUrl = "http://localhost:3000"
export default serverUrl